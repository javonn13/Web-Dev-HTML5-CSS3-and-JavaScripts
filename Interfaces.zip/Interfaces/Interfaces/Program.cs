﻿using System;
using System.Collections.Generic;

namespace Interfaces
{
    class Program
    {
        public static void PrintMe(IPrintElon obj)
        {
            Console.WriteLine(obj.PrintMSSA());
            Console.WriteLine(obj.PrintMSSA2());
        }

        static void Main(string[] args)
        {
            Student st = new Student();
            User us = new User();
            GraduateStudent gs = new GraduateStudent();
            PrintMe(us);
            PrintMe(st);
            PrintMe(gs);

            List<int> numbers = new List<int>();
            numbers.Add(10);
            numbers.Add(50);
            numbers.Add(30);
            numbers.Add(20);

            numbers.Sort();
            foreach(var n in numbers)
                Console.WriteLine(n);



            List<Student> numbers2 = new List<Student>();
            Student st1 = new Student();
            st1.Name = "Alex";
            st1.Major = "CS";
            st1.GPA = 2.0;
            numbers2.Add(st1);

            Student st2 = new Student();
            st2.Name = "Elon";
            st2.Major = "Alexa";
            st2.GPA = 4.1;
            numbers2.Add(st2);

            Student st3 = new Student();
            st3.Name = "Yauchin";
            st3.Major = "Math";
            st3.GPA = 3.5;
            numbers2.Add(st3);

            Student st4 = new Student();
            st4.Name = "Chris";
            st4.Major = "CS";
            st4.GPA = 4.0;
            numbers2.Add(st4);

            numbers2.Sort();

            foreach (var n in numbers2)
                Console.WriteLine(n);

        }
    }

    interface IPrintElon
    {
        string PrintMSSA();
        string PrintMSSA2();
    }

    class Student : IPrintElon, IComparable
    {
        public string Name { get; set; }
        public string Major { get; set; }
        public double GPA { get; set; }

        public int CompareTo(object obj)
        {
            Student left = this;
            Student right = (Student)obj;

            //return left.Name.CompareTo(right.Name); 
            //return left.Major.CompareTo(right.Major);
            return left.GPA.CompareTo(right.GPA);

        }

        public string PrintMSSA() { return "hello1"; }
        public string PrintMSSA2() { return "hello2"; }

        public override string ToString()
        {
            return Name + " " + Major + " " + GPA;
        }
    }

    class GraduateStudent: Student
    {
        public bool  HasScholarship { get; set; }
    }

    class User : IPrintElon
    {
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public int ID { get; set; }

        public string PrintMSSA() { return "hello3"; }
        public string PrintMSSA2() { return "hello4"; }
    }
}
